<p align="center">
  <img src="main.svg" width="800" height="400">
</p>

## This is all free! Want to contribute/support me? 
**BTC ADDRESS**: 12fMcxiRugD9pNambV1ZvNhT9uQVSUE7Hf
**Patreon** : https://www.patreon.com/terrible_dev

## Star the repo

**After Installing**
```diff
+ npm i (this will install all packages)
+ modify .env.sample to be .env
+ make a issue on this repo, with any questions
```
