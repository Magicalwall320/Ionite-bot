const { Client, Collection } = require('discord.js');
const fs = require('fs');

const { BOT_TOKEN, PREFIX } = process.env;

const client = new Client({ disableEveryone: true });

client.commands = new Collection();
client.aliases = new Collection();
client.prefix = "%";
client.categories = fs.readdirSync('./commands/');

['command', 'event'].forEach((handler) => {
	require(`./handlers/${handler}`)(client);
});

client.on('guildMemberAdd', async (member) => {
	await require('./events/guild/memberAdd')(member);
});

client.on('guildMemberRemove', async (message) => {
	await require('./events/guild/memberRemove')(message);
});

client.login('OTEyMjc0MTg3OTA3ODkxMjIw.YZtjiw.uzQm_xPEkwoU48mdyj_jdF1ZyYY')
	.then(() => console.log('[BOT INFO] - Bot has successfully logged in'));
