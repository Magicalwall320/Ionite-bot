module.exports = {
	name: 'restart',
	category: 'owner',
	run: async (client, message, args) => {
		if (message.author.id !== '478929262792015873') {
			return message.channel.send('You cannot use this command!');
		}
		await message.channel.send('Restarting bot...');
		return process.exit();
	},
};
